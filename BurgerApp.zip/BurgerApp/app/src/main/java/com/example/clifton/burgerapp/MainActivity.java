package com.example.clifton.burgerapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,
        CompoundButton.OnCheckedChangeListener, View.OnFocusChangeListener {

    RadioButton white;
    RadioButton wheat;
    RadioButton beef;
    RadioButton chic;
    RadioButton turk;
    RadioButton fish;
    RadioButton veg;
    CheckBox shroom;
    CheckBox lett;
    CheckBox tom;
    CheckBox pickle;
    CheckBox mayo;
    CheckBox must;
    EditText count;
    Button calc;
    TextView cost;
    TextView cals;

    Burger burger;
    Calculator calculator;

    LinearLayout costCal;

    Toast toast;
    Toast toastNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        white = (RadioButton) findViewById(R.id.white);
        wheat = (RadioButton) findViewById(R.id.wheat);
        beef = (RadioButton) findViewById(R.id.beef);
        chic = (RadioButton) findViewById(R.id.chic);
        turk = (RadioButton) findViewById(R.id.turkey);
        fish = (RadioButton) findViewById(R.id.fish);
        veg = (RadioButton) findViewById(R.id.veggie);
        shroom = (CheckBox) findViewById(R.id.shroom);
        lett = (CheckBox) findViewById(R.id.lettuce);
        tom = (CheckBox) findViewById(R.id.tom);
        pickle = (CheckBox) findViewById(R.id.pic);
        mayo = (CheckBox) findViewById(R.id.mayo);
        must = (CheckBox) findViewById(R.id.must);
        count = (EditText) findViewById(R.id.count);
        calc = (Button) findViewById(R.id.calc);
        cost = (TextView) findViewById(R.id.cost);
        cals = (TextView) findViewById(R.id.cal);

        costCal = (LinearLayout) findViewById(R.id.line1);

        white.setOnClickListener(this);
        wheat.setOnClickListener(this);
        beef.setOnClickListener(this);
        chic.setOnClickListener(this);
        turk.setOnClickListener(this);
        fish.setOnClickListener(this);
        veg.setOnClickListener(this);
        calc.setOnClickListener(this);

        shroom.setOnCheckedChangeListener(this);
        lett.setOnCheckedChangeListener(this);
        tom.setOnCheckedChangeListener(this);
        pickle.setOnCheckedChangeListener(this);
        mayo.setOnCheckedChangeListener(this);
        must.setOnCheckedChangeListener(this);

        burger = new Burger();
        calculator = new Calculator(burger);

        count.setOnClickListener(this);
        count.setOnFocusChangeListener(this);

        toast = Toast.makeText(getApplicationContext(), "You ordered too many toppings.", toast.LENGTH_SHORT);
        toastNum = Toast.makeText(getApplicationContext(), "That's a lot of burgers!", toast.LENGTH_SHORT);

        //count.setOnEditorActionListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == white.getId()) {
            burger.setBun("white");
        } else if (v.getId() == wheat.getId()) {
            burger.setBun("wheat");
        } else if (v.getId() == beef.getId()) {
            burger.setPatty("beef");
        } else if (v.getId() == chic.getId()) {
            burger.setPatty("chicken");
        } else if (v.getId() == turk.getId()) {
            burger.setPatty("turkey");
        } else if (v.getId() == fish.getId()) {
            burger.setPatty("fish");
        } else if (v.getId() == veg.getId()) {
            burger.setPatty("veggie");
        } else if(v.getId() == count.getId()) {
            costCal.setVisibility(View.INVISIBLE);
            return;
        }
        if (Integer.parseInt(count.getText().toString()) > 15) {
            makeNumToast();
        }
        int[] vals = calculator.calculate(Integer.parseInt(count.getText().toString()));
        cost.setText("$" + String.format("%.2f", (vals[1] / 100.0)));
        cals.setText(vals[0] + "");
        costCal.setVisibility(View.VISIBLE);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == shroom.getId()) {
            if(isChecked) {
                burger.addTopping("mushrooms", this);
            } else {
                burger.removeTopping("mushrooms");
            }
        } else if (buttonView.getId() == lett.getId()) {
            if(isChecked) {
                burger.addTopping("lettuce", this);
            } else {
                burger.removeTopping("lettuce");
            }
        } else if (buttonView.getId() == tom.getId()) {
            if(isChecked) {
                burger.addTopping("tomatoes", this);
            } else {
                burger.removeTopping("tomatoes");
            }
        } else if (buttonView.getId() == pickle.getId()) {
            if(isChecked) {
                burger.addTopping("pickle", this);
            } else {
                burger.removeTopping("pickle");
            }
        } else if (buttonView.getId() == mayo.getId()) {
            if(isChecked) {
                burger.addTopping("mayo", this);
            } else {
                burger.removeTopping("mayo");
            }
        } else if (buttonView.getId() == must.getId()) {
            if(isChecked) {
                burger.addTopping("mustard", this);
            } else {
                burger.removeTopping("mustard");
            }
        }
        if (Integer.parseInt(count.getText().toString()) > 15) {
            makeNumToast();
        }
        int[] vals = calculator.calculate(Integer.parseInt(count.getText().toString()));
        cost.setText("$" + String.format("%.2f", (vals[1] / 100.0)));
        cals.setText(vals[0] + "");
        costCal.setVisibility(View.VISIBLE);
    }

    void uncheck(String s) {
        toast.show();
        if (s.equals("mushrooms")) {
            shroom.setChecked(false);
        } else if (s.equals("tomatoes")) {
            tom.setChecked(false);
        } else if (s.equals("pickle")) {
            pickle.setChecked(false);
        } else if (s.equals("lettuce")) {
            lett.setChecked(false);
        } else if (s.equals("mayo")) {
            mayo.setChecked(false);
        } else if (s.equals("mustard")) {
            must.setChecked(false);
        }
    }
    void makeNumToast() {
        toastNum.show();
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        costCal.setVisibility(View.INVISIBLE);
    }
}
