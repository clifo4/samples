package com.example.clifton.burgerapp;

import java.util.ArrayList;
import java.util.Queue;

/**
 * Created by Clifton on 9/10/2017.
 */

public class Burger {
    private String bun;
    private String patty;
    private ArrayList<String> toppings;
    private int num;

    public Burger() {
        bun = "";
        patty = "";
        num = 0;
        toppings = new ArrayList<String>();
    }

    public void setBun(String s) {
        bun = s;
    }

    public void setPatty(String s) {
        patty = s;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void addTopping(String s, MainActivity main) {
        if(toppings.size() == 3) {
            main.uncheck(toppings.remove(0));
        }
        toppings.add(s);
    }

    public String getBun() {
        return bun;
    }

    public String getPatty() {
        return patty;
    }

    public int getNum() {
        return num;
    }

    public String[] getToppings() {
        String[] temp = new String[toppings.size()];
        toppings.toArray(temp);
        return temp;
    }

    public void removeTopping(String s) {
        toppings.remove(s);
    }
}
