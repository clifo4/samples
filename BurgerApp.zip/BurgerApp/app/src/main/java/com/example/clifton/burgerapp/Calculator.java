package com.example.clifton.burgerapp;

import java.util.Hashtable;

/**
 * Created by Clifton on 9/10/2017.
 */

public class Calculator {

    private Hashtable<String, Vals> map;
    private Burger burger;

    public Calculator(Burger burger) {
        this.burger = burger;
        map = new Hashtable<String, Vals>();

        map.put("white", new Vals(140, 100));
        map.put("wheat", new Vals(100, 100));
        map.put("beef", new Vals(240, 550));
        map.put("chicken", new Vals(180, 500));
        map.put("turkey", new Vals(190, 500));
        map.put("fish", new Vals(95, 750));
        map.put("veggie", new Vals(80, 450));
        map.put("mushrooms", new Vals(60, 100));
        map.put("tomatoes", new Vals(20, 30));
        map.put("lettuce", new Vals(20, 30));
        map.put("pickle", new Vals(30, 50));
        map.put("mayo", new Vals(100, 0));
        map.put("mustard", new Vals(60, 0));
    }

    public int[] calculate(int num) {
        int cals = 0;
        int price = 0;

        String bun = burger.getBun();
        String patty = burger.getPatty();
        String[] toppings = burger.getToppings();

        if (!bun.equals("")) {
            cals += map.get(bun).cals;
            price += map.get(bun).price;
        }
        if (!patty.equals("")) {
            cals += map.get(patty).cals;
            price += map.get(patty).price;
        }

        for (int i = 0; i < toppings.length; i++) {
            String s = toppings[i];
            cals += map.get(s).cals;
            price += map.get(s).price;
        }
        cals *= num;
        price *= num;
        int[] temp = {cals, price};
        return temp;
    }
    private class Vals {
        private int cals;
        private int price;

        private Vals(int cal, int price) {
            cals = cal;
            this.price = price;
        }
    }
}
